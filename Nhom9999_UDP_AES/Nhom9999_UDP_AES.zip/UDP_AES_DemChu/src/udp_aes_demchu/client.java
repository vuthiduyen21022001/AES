
package udp_aes_demchu;

import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;


public class client {
    

    public static void main(String[] args)throws UnknownHostException, IOException {
        try {
            while (true) {                
            //client tạo dragramsocket
            DatagramSocket dataSocket= new DatagramSocket();
            // Tạo các đối tượng dữ liệu            
            Scanner sc= new Scanner(System.in);
            System.out.println("Nhap chuoi:");
            String strName = sc.nextLine(); 
            System.out.println("Nhap khoa:");
            String khoa =sc.nextLine();
            //Giai đoạn 3.2: tạo các đối tượng địa chỉ, cổng, mảng dữ liệu....
            InetAddress ip =InetAddress.getByName("localhost");
            int port = 8888;
            byte[] readBuffer = new byte[1024];
            byte[] writeBuffer = null;
            // Ma hoatruoc khi gui di 

            String myKey="123456789";
            //String myKey= khoa;
            MessageDigest sha = MessageDigest.getInstance("SHA-1");
            byte[] key = myKey.getBytes("UTF-8");
            key = sha.digest(key);
            key = Arrays.copyOf(key, 16);
            SecretKeySpec secretKey = new SecretKeySpec(key, "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] byteEncrypted = cipher.doFinal(strName.getBytes());
            String Nameencrypted = Base64.getEncoder().encodeToString(byteEncrypted);
            writeBuffer = Nameencrypted.getBytes();
            //Gửi dữ liệu đi 
            System.out.println("Client Mã hoá: \t"+ Nameencrypted);
            DatagramPacket sendPacket= new DatagramPacket(writeBuffer, writeBuffer.length, ip, port);
            dataSocket.send(sendPacket);
            
            // nhan data tu server gui qua
            DatagramPacket receiverDatagram= new DatagramPacket(readBuffer, readBuffer.length);
            dataSocket.receive(receiverDatagram);            
                      
            String line = new String(receiverDatagram.getData());
            System.out.println("Client Receiver: \t "+ line);
            }            
        } catch (Exception e) {
            e.printStackTrace();
        }   
    }
}