
package udp_aes_demchu;


import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
        
public class server {
     public static HashMap<Character, Integer> characterCount(String inputString)
    {
        // Tạo HashMap, khóa: Giá trị ký tự: lần xuất hiện dưới dạng Số nguyên
        HashMap<Character, Integer> eachCharCountMap = new HashMap<Character, Integer>();
        // Chuyển chuỗi inputString thành mảng char
        char[] charArray = inputString.toCharArray();
        // truyền qua từng ký tự của charArray
        for (char c : charArray)
        {
            if(eachCharCountMap.containsKey(c))
            {
                // Nếu char có trong mỗiCharCountMap, số gia tăng là 1
                eachCharCountMap.put(c, eachCharCountMap.get(c)+1);
            }
            else
            {                // Nếu char không có trong eachCharCountMap,
                // Đưa biểu đồ này vào eachCharCountMap với 1 vì nó là giá trị ban đầu
                eachCharCountMap.put(c, 1);
            }
        }
        // Hiển thị eachCharCountMap
        System.out.println("Số lần xuất hiện của ký tự");
        System.out.println(eachCharCountMap);
        return eachCharCountMap;
    }
    public static void main(String[] args) throws UnknownHostException, IOException{
        try {
            //server tạo datagram socket
            DatagramSocket server =new DatagramSocket(8888);
            System.out.println("Server đang chạy...");
            //Server nhận gói dữ liệu từ client gửi lên
            while (true) {            
                byte[] doc = new byte[1024];
                DatagramPacket receiverDatagram= new DatagramPacket(doc, doc.length);
                server.receive(receiverDatagram);               
                String Nhandata = new String(receiverDatagram.getData());
                System.out.println("Kết nối...");
                System.out.println("Nhận chuỗi mã hoá: " + Nhandata);
                
                if (Nhandata == "")
                    return;
                String keyn = "";
                String text = "";
                for (int i = 0; i < Nhandata.length(); i++) {
                    if (Nhandata.charAt(i) == '+' && Nhandata.charAt(i + 1) == '+') {
                        keyn = Nhandata.substring(0, i).trim();
                        text = Nhandata.substring(i + 2).trim();
                        break;
                    }
                }
            //nhan du lieu va giai ma Aes           
            String myKey=keyn;
            MessageDigest sha = MessageDigest.getInstance("SHA-1");
            byte[] key = myKey.getBytes("UTF-8");
            key = sha.digest(key);
            key = Arrays.copyOf(key, 16);
            SecretKeySpec secretKey = new SecretKeySpec(key, "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, cipher.getParameters());
            String strDecryptedText = new String(cipher.doFinal(Base64.getMimeDecoder().decode(text)));
            System.out.println("Giải mã: " + strDecryptedText);   
            // Xu ly dem
              byte[] ghi = new byte[1024]; 
              HashMap<Character, Integer> kq = characterCount(strDecryptedText);
              ghi = String.valueOf(kq).getBytes(); 
            // truyen du lieu ve client 
              InetAddress host= receiverDatagram.getAddress();
              int port = receiverDatagram.getPort();
              DatagramPacket gui = new DatagramPacket(ghi, ghi.length, host, port);
              server.send(gui);
            }
        } catch (Exception ex) {
            Logger.getLogger(server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
